RNC web translation review bundle

Review every row in each CSV. source_spanish is the canonical source; english_reference is a cross-check, not an authority for institutional or epidemiological meaning. Mark review_decision as approved or needs_changes, enter corrected_translation or corrected_plural_translations when needed, and record reviewer_notes. In REVIEW-MANIFEST.json fill linguistic_attestation with reviewer, qualification and reviewed_at (YYYY-MM-DD). Do not change codes, placeholders, or source meanings.

Return this completed bundle as the linguistic review report. The release gate still requires independent institutional and functional evidence. The manifest pins the catalogs reviewed when this bundle was created; any later catalog edits require a fresh review.
